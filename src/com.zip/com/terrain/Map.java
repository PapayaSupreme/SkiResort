package com.terrain;

import com.enums.Point;

public class Map extends POI{

    public Map(String name, int id, Point location) {
        super(name, id, location);
    }
}
