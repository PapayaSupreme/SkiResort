package com.terrain;

import com.enums.Point;

public class Restaurant extends POI {

    public Restaurant(String name, int id, Point location) {
        super(name, id, location);
    }
}
