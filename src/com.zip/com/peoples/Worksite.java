package com.peoples;

public interface Worksite {

    String getName();
    int getId();

    void setName(String name);
}
