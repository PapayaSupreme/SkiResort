package com.peoples;

public class Guest extends Person {

    public Guest(int id) {
        super(id);
    }
}
