package com.enums;

public enum SnowConsistency { POWDER, GROOMED, PACKED, ICY, SLUSH, CRUST, ARTIFICIAL, NONE }
