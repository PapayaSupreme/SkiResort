package com.enums;

public enum EmployeeType { PISTER, LIFT_OP, RESTAURATION, MAINTENANCE }
