package com.enums;

public enum LiftType { TREADMILL, TELESKI, SEATED, CABIN}
