package com.enums;

public enum PassCategory { BABY, CHILD, ADULT, SENIOR, SUPERSENIOR, INSTRUCTOR, EMPLOYEE, FREE, VIP }
