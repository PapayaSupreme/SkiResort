package com.enums;

public record Point(double x, double y, double z) {}