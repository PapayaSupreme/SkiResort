package com.enums;

public enum SlopeType { PISTE, SLALOM, SNOWPARK, UNGROOMED, OFF_PISTE}
