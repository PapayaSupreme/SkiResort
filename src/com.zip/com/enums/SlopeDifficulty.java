package com.enums;

public enum SlopeDifficulty { GREEN, BLUE, RED, BLACK }
