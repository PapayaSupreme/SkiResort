package com.enums;

public enum POIStatus { OPEN, CLOSED, OUT_OF_SERVICE }
