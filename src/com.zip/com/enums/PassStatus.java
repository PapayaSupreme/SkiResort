package com.enums;

public enum PassStatus { ACTIVE, SUSPENDED, EXPIRED }