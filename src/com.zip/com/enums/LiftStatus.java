package com.enums;

public enum LiftStatus { OPEN, CLOSED, MAINTENANCE, WIND_HOLD }
