package com.enums;

public enum SkiSchool { ESF, ISF }
